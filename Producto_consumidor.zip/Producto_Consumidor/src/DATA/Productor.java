package DATA;

public class Productor extends Thread {
    private Cola miCola;

    public Productor(Cola c) {
        this.miCola = c;
    }

    public void run() {
        while (true) {
            try {
                miCola.poner("PING");
                Thread.sleep(400);

                miCola.poner("PONG");
                Thread.sleep(400);
            } catch (Exception e) {
            }
        }
    }
}
