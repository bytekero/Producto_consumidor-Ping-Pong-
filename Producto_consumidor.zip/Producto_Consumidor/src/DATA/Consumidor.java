package DATA;

public class Consumidor extends Thread {
    private Cola miCola;

    public Consumidor(Cola c) {
        this.miCola = c;
    }

    public void run() {
        while (true) {
            String dato = miCola.sacar();
            System.out.print(dato + " ");
        }
    }
}
