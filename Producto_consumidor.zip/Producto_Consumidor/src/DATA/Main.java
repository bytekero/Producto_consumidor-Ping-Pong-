package DATA;

public class Main {
	public static void main(String[] args) {
        Cola colaCompartida = new Cola();
        
        Productor p = new Productor(colaCompartida);
        Consumidor c = new Consumidor(colaCompartida);
        
        p.start();
        c.start();
    }
}
