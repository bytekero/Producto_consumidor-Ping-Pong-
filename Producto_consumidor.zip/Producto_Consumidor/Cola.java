package DATA;

public class Cola {
    private String texto;
    private boolean disponible = false;

    public synchronized String sacar() {
        while (disponible == false) {
            try {
                wait();
            } catch (Exception e) {
            }
        }
        disponible = false;
        notifyAll();
        return texto;
    }

    public synchronized void poner(String nuevoTexto) {
        while (disponible == true) {
            try {
                wait();
            } catch (Exception e) {
            }
        }
        texto = nuevoTexto;
        disponible = true;
        notifyAll();
    }
}
